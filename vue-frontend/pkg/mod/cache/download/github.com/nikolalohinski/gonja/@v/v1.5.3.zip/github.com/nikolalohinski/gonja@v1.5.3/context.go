package gonja

// import (
// 	"github.com/nikolalohinski/gonja/exec"
// )

type Context map[string]interface{}

// func (c Context) Get(name string) interface{} {
// 	return nil
// }

// // Update updates this context with the key/value-pairs from another context.
// func (c Context) Update(other exec.Context) Context {
// 	for k, v := range other.AsMap() {
// 		c[k] = v
// 	}
// 	return c
// }
