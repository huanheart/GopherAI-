package statements

import "github.com/nikolalohinski/gonja/exec"

// All holds all builtins statements for easier registeration
var All = exec.StatementSet{}
