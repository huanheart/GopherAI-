package gonja

import "github.com/nikolalohinski/gonja/config"

type Config config.Config

var NewConfig = config.NewConfig
