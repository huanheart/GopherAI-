package builtins

import "github.com/nikolalohinski/gonja/builtins/statements"

// Statements exports all builtins statements
var Statements = statements.All
