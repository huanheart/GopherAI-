package gonja

import (
	_ "github.com/nikolalohinski/gonja/docs"
)
