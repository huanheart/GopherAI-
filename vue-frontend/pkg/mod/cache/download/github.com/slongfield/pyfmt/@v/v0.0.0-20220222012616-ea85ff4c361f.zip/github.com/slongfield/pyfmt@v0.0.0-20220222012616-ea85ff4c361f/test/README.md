# Testing

In this package, we test the Go implementation of Python's format against Python's formating
methods.

Inspired by work at:
  * https://blog.heroku.com/see_python_see_python_go_go_python_go

  * https://blog.filippo.io/building-python-modules-with-go-1-5/
