// Package emperror provides error handling solutions and tools for libraries and applications.
package emperror
