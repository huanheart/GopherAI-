package readline

func handleCharCtrlZ(fd uintptr, state any) (string, error) {
	// not supported
	return "", nil
}
