package pooling_test

import (
	"bytes"
	"os"
	"slices"
	"testing"

	"github.com/eino-contrib/ollama/discover"
	fsggml "github.com/eino-contrib/ollama/fs/ggml"
	"github.com/eino-contrib/ollama/ml"
	"github.com/eino-contrib/ollama/ml/backend/ggml"
	"github.com/eino-contrib/ollama/ml/nn/pooling"
	"github.com/google/go-cmp/cmp"
)

func setup(tb testing.TB, n int) ml.Backend {
	tb.Helper()

	f, err := os.CreateTemp(tb.TempDir(), "*.bin")
	if err != nil {
		tb.Fatal(err)
	}
	defer f.Close()

	if err := fsggml.WriteGGUF(f, fsggml.KV{
		"general.architecture": "test",
		"test.block_count":     uint32(1),
	}, []*fsggml.Tensor{
		{Name: "blk.0.weight", Shape: []uint64{1}, WriterTo: bytes.NewBuffer(make([]byte, 4))},
	}); err != nil {
		tb.Fatal(err)
	}

	var gpuLayers ml.GPULayersList
	if gpus := discover.GetGPUInfo(); len(gpus) > 0 {
		gpuLayers = append(gpuLayers, ml.GPULayers{
			ID: gpus[0].ID,
			Layers: slices.Collect(func(yield func(int) bool) {
				for i := range n {
					if !yield(i) {
						return
					}
				}
			}),
		})
	}
	b, err := ggml.New(f.Name(), ml.BackendParams{AllocMemory: true, GPULayers: gpuLayers})
	if err != nil {
		tb.Fatal(err)
	}

	return b
}

func TestForward(t *testing.T) {
	cases := map[pooling.Type][]float32{
		pooling.TypeMean: {4, 5, 6, 7, 8, 9, 10, 11},
		pooling.TypeCLS:  {0, 1, 2, 3, 4, 5, 6, 7},
		pooling.TypeLast: {8, 9, 10, 11, 12, 13, 14, 15},
	}
	for typ, want := range cases {
		t.Run(typ.String(), func(t *testing.T) {
			b := setup(t, 99)
			defer b.Close()

			ctx := b.NewContext()
			defer ctx.Close()

			tt := ctx.Input().Arange(0, 16, 1, ml.DTypeF32).Reshape(ctx, 8, 2)
			tt = typ.Forward(ctx, tt)

			ctx.Forward(tt).Compute(tt)
			if diff := cmp.Diff(want, tt.Floats()); diff != "" {
				t.Error(diff)
			}
		})
	}
}
