package backend

import (
	_ "github.com/eino-contrib/ollama/ml/backend/ggml"
)
