package cpu

import _ "github.com/eino-contrib/ollama/ml/backend/ggml/ggml/src/ggml-cpu/arch/arm"
